export const CREATE_TASK = "task/createTask";
export const DONE_TASK = "task/doneTask";
export const RESET_TASK = "task/resetTask";
const action = {
  CREATE_TASK,
  DONE_TASK,
  RESET_TASK,
};

export default action;
