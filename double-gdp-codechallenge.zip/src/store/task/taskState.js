const taskState = {
  tasks: [],
};

export default taskState;
