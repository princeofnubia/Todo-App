const tasks = [
  {
    taskName: "DoubleGDP React Coding Challenge",
    taskDescription: "Write a todo app with the provided screens",
  },
  {
    taskName: "Visit Grandma",
    taskDescription: "Visit my grand ma",
  },
  {
    taskName: "Go Shopping",
    taskDescription: "Go Shopping with my wife",
  },
  {
    taskName: "Visit The Zoo",
    taskDescription: "Take the kid to visit the zoo",
  },
  {
    taskName: "Schedule Demo",
    taskDescription: "Schedule demo with the customer",
  },
  {
    taskName: "Team Scrum Meeting",
    taskDescription: "Attend team scrum meeting",
  },
  {
    taskName: "French Class",
    taskDescription: "Go to french class for rehearsal",
  },
];

export default tasks;
